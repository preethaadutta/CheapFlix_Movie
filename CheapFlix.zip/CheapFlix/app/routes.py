from app import app, db, mail
from flask import flash, session, render_template, request, redirect, url_for
from app.models import User, Movie, Payment
from flask_mail import Message
from datetime import datetime
from sqlalchemy import extract

# Define static exchange rates (you can extend this later)
EXCHANGE_RATES = {
    'USD': 1.35,  # 1 GBP = 1.35 USD
    'EUR': 1.18,  # 1 GBP = 1.18 EUR
    'GBP': 1.00   # GBP to GBP (no conversion needed)
}

# Homepage Route
@app.route('/')
def index():
    movies = Movie.query.all()
    return render_template('index.html', movies=movies)
'''
# User Registration Route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']  # Store password as plain text
        subscription_level = request.form['subscription_level']
        
        # Create a new user
        new_user = User(username=username, email=email, password=password, subscription_level=subscription_level)
        
        try:
            db.session.add(new_user)
            db.session.commit()
            return redirect(url_for('home'))
        except:
            return 'There was an issue adding the user'
    return render_template('register.html')
'''
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        subscription_level = request.form.get('subscription_level')
        #device_id = request.form.get('device_id')

        # Basic check
        if User.query.filter_by(email=email).first():
            flash('Email already registered', 'error')
            return redirect(url_for('register'))

        new_user = User(
            username=username,
            email=email,
            password=password,
            subscription_level=subscription_level,
            #device_id=device_id
        )

        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful. Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# User Login Route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Query the user by email
        user = User.query.filter_by(email=email, password=password).first()
        
        # Check if the user exists and the password matches
        if user and user.password == password:  # Compare plain text passwords
            session['user_id'] = user.id  # Store user ID in session
            return redirect(url_for('dashboard', user_id=user.id)) # Redirect to dashboard
        else:
            flash("Invalid credentials", "error") # Flash the error message
            return redirect(url_for('login')) # Redirect back to login page
            #return 'Invalid credentials'
    return render_template('login.html')
@app.route('/logout')
def logout():
    session.pop('user_id', None)  # Remove user_id from session
    return redirect(url_for('index'))  # Redirect to home page (or login page)
'''
# User Dashboard Route
@app.route('/dashboard/<int:user_id>', methods=['GET'])
def dashboard(user_id):
    user = User.query.get_or_404(user_id)
    
    # Get movies available based on the user's subscription level
    movies = Movie.query.filter_by(subscription_level_required=user.subscription_level).all()
    
    return render_template('dashboard.html', user=user, movies=movies)
'''
'''
# Manage Subscription (Upgrade/Downgrade)
@app.route('/dashboard/<int:user_id>', methods=['POST', 'GET'])
def manage_subscription(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        new_subscription = request.form['new_subscription']
        
        # Update the subscription level
        user.subscription_level = new_subscription
        
        try:
            db.session.commit()
            return redirect(url_for('dashboard', user_id=user.id))
        except:
            return 'There was an issue updating your subscription'
    
    # Display movies based on the current subscription level
    movies = Movie.query.filter_by(subscription_level_required=user.subscription_level).all()
    return render_template('dashboard.html', user=user, movies=movies)
'''
'''
# Manage Subscription (Upgrade/Downgrade)
@app.route('/dashboard/<int:user_id>', methods=['POST', 'GET'])
def manage_subscription(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        new_subscription = request.form['new_subscription']
        
        # Calculate the price difference for the upgrade/downgrade
        old_price = 4.99 if user.subscription_level == 'Level 1' else 7.99 if user.subscription_level == 'Level 2' else 9.99
        new_price = 4.99 if new_subscription == 'Level 1' else 7.99 if new_subscription == 'Level 2' else 9.99
        payment_difference = new_price - old_price

        # Simulate a payment
        payment_method = 'Credit Card'  # Fixed payment method
        payment_date = datetime.now()

        new_payment = Payment(
            user_id=user.id,
            amount=payment_difference,
            payment_method=payment_method,
            date=payment_date
        )
        
        # Commit the payment record
        db.session.add(new_payment)
        db.session.commit()

        # Update the user's subscription level
        user.subscription_level = new_subscription
        db.session.commit()

        return redirect(url_for('dashboard', user_id=user.id))

    # Display movies based on the current subscription level
    movies = Movie.query.filter_by(subscription_level_required=user.subscription_level).all()
    return render_template('dashboard.html', user=user, movies=movies)
'''

'''
# Manage Subscription (GET for displaying, POST for updating)
@app.route('/dashboard/<int:user_id>', methods=['GET', 'POST'])
def dashboard(user_id):
    user = User.query.get_or_404(user_id)
    
    # Default currency is GBP, but we will check the form for currency selection
    selected_currency = request.form.get('currency', 'GBP')  # Default to GBP if not set
    exchange_rate = EXCHANGE_RATES.get(selected_currency, 1.00)  # Get rate or default to 1 (GBP to GBP)
    price_difference = None  # Default value

    if request.method == 'POST':
        new_subscription = request.form['new_subscription']
        old_subscription = user.subscription_level

        print(f"[DEBUG] Old: {old_subscription}, New: {new_subscription}")

        if old_subscription != new_subscription:
            # Pricing logic
            old_price = 4.99 if old_subscription == 'Level 1' else 7.99 if old_subscription == 'Level 2' else 9.99
            new_price = 4.99 if new_subscription == 'Level 1' else 7.99 if new_subscription == 'Level 2' else 9.99
            price_difference = (new_price - old_price) * exchange_rate  # Apply conversion rate

            # Create a payment record with converted price
            payment_method = 'Credit Card'  # Simulated payment method
            payment_date = datetime.now()
            new_payment = Payment(
                user_id=user.id,
                amount=price_difference,
                payment_method=payment_method,
                date=payment_date
            )
            db.session.add(new_payment)

            # ✅ NEW WAY TO UPDATE SUBSCRIPTION LEVEL
            db.session.query(User).filter_by(id=user.id).update({'subscription_level': new_subscription})
            db.session.commit()

            print("[DEBUG] Subscription level updated using .update()")
            # After updating, send an email receipt to the user
            send_receipt_email(user.email, price_difference, new_subscription, selected_currency)

        return redirect(url_for('dashboard', user_id=user.id))

    # GET request
    updated_user = User.query.get_or_404(user_id)
    movies = Movie.query.filter_by(subscription_level_required=updated_user.subscription_level).all()
    
    # Convert prices for display based on the selected currency
    movies_in_currency = []
    for movie in movies:
        movie_price = 4.99 if movie.subscription_level_required == 'Level 1' else 7.99 if movie.subscription_level_required == 'Level 2' else 9.99
        movie_in_selected_currency = {
            'title': movie.title,
            'description': movie.description,
            'price_in_selected_currency': round(movie_price * exchange_rate, 2)  # Convert price
        }
        movies_in_currency.append(movie_in_selected_currency)
    return render_template('dashboard.html', user=updated_user, movies=movies, price_difference=price_difference, selected_currency=selected_currency)
'''

# Manage Subscription (GET for displaying, POST for updating)
@app.route('/dashboard/<int:user_id>', methods=['GET', 'POST'])
def dashboard(user_id):
    user = User.query.get_or_404(user_id)

    # Default to GBP for GET requests
    selected_currency = 'GBP'
    price_difference = None

    if request.method == 'POST':
        # Get values from submitted form
        new_subscription = request.form['new_subscription']
        selected_currency = request.form.get('currency', 'GBP')
        exchange_rate = EXCHANGE_RATES.get(selected_currency, 1.00)

        old_subscription = user.subscription_level
        print(f"[DEBUG] Old: {old_subscription}, New: {new_subscription}")

        if old_subscription != new_subscription:
            # Pricing logic
            old_price = 4.99 if old_subscription == 'Level 1' else 7.99 if old_subscription == 'Level 2' else 9.99
            new_price = 4.99 if new_subscription == 'Level 1' else 7.99 if new_subscription == 'Level 2' else 9.99
            price_difference = round((new_price - old_price) * exchange_rate, 2)

            # Simulate payment
            new_payment = Payment(
                user_id=user.id,
                amount=price_difference,
                payment_method='Credit Card',
                date=datetime.now()
            )
            db.session.add(new_payment)

            # Update subscription level
            db.session.query(User).filter_by(id=user.id).update({'subscription_level': new_subscription})
            db.session.commit()

            print("[DEBUG] Subscription level updated using .update()")

            # Send simulated email receipt
            send_receipt_email(user.email, price_difference, new_subscription, selected_currency)

        #return redirect(url_for('dashboard', user_id=user.id))
        return redirect(url_for('dashboard', user_id=user.id, price_difference=price_difference, currency=selected_currency))


    # GET request handling
    selected_currency = request.args.get('currency', 'GBP')
    
    price_difference = request.args.get('price_difference')

    exchange_rate = EXCHANGE_RATES.get(selected_currency, 1.00)

    # Reload updated user data
    updated_user = User.query.get_or_404(user_id)

    # Convert movies for selected currency
    movies = Movie.query.filter_by(subscription_level_required=updated_user.subscription_level).all()
    movies_in_currency = []
    for movie in movies:
        movie_price = 4.99 if movie.subscription_level_required == 'Level 1' else 7.99 if movie.subscription_level_required == 'Level 2' else 9.99
        movies_in_currency.append({
            'title': movie.title,
            'description': movie.description,
            'price_in_selected_currency': round(movie_price * exchange_rate, 2)
        })

    return render_template(
        'dashboard.html',
        user=updated_user,
        movies=movies_in_currency,
        price_difference=price_difference,
        selected_currency=selected_currency
    )

# Simulate Payment when Subscription is Changed
@app.route('/manage_subscription/<int:user_id>', methods=['POST'])
def manage_subscription(user_id):
    user = User.query.get_or_404(user_id)
    new_subscription = request.form['new_subscription']
    
    # Price difference logic (simulate payment)
    old_price = 4.99 if user.subscription_level == 'Level 1' else 7.99 if user.subscription_level == 'Level 2' else 9.99
    new_price = 4.99 if new_subscription == 'Level 1' else 7.99 if new_subscription == 'Level 2' else 9.99
    payment_difference = new_price - old_price

    # Simulate a payment (record payment in the database)
    payment_method = 'Credit Card'  # Simulating a fixed payment method
    payment_date = datetime.now()
    
    new_payment = Payment(
        user_id=user.id,
        amount=payment_difference,
        payment_method=payment_method,
        date=payment_date
    )
    
    # Commit payment record
    db.session.add(new_payment)
    db.session.commit()

    # Update the subscription level
    user.subscription_level = new_subscription
    db.session.commit()

    return redirect(url_for('dashboard', user_id=user.id))


# Email receipt simulation function
def send_receipt_email(user_email, payment_amount, subscription_level, currency):
    # Create the email message
    subject = f"CheapFlix Subscription Receipt - {subscription_level} - {currency}"
    body = f"Dear user,\n\nThank you for upgrading to {subscription_level}!\nYour payment of {payment_amount} {currency} has been processed.\n\nEnjoy your streaming experience!\n\nBest regards,\nCheapFlix Team"
    
    # Simulating sending email (printing to console)
    print(f"[EMAIL SIMULATION] Sending receipt to {user_email}:\nSubject: {subject}\n{body}")
    
    # You can uncomment the following code to actually send emails when running on a real server:
    # msg = Message(subject=subject, recipients=[user_email], body=body)
    # mail.send(msg)
    
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == 'admin' and password == 'admin123':  # Hardcoded admin credentials
            session['admin_id'] = 1  # Store admin session
            return redirect(url_for('admin_dashboard')) # Redirect to admin dashboard
        else:
            flash("Invalid credentials", "error")
            return "Invalid credentials"
    return render_template('admin_login.html')
@app.route('/admin_logout')
def admin_logout():
    session.pop('admin_id', None)  # Remove admin_id from session
    return redirect(url_for('admin_login'))  # Redirect to admin login page

@app.route('/admin_dashboard')
def admin_dashboard():
    return render_template('admin_dashboard.html')

@app.route('/add_movie', methods=['GET', 'POST'])
def add_movie():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        level = request.form['subscription_level_required']

        new_movie = Movie(title=title, description=description, subscription_level_required=level)
        db.session.add(new_movie)
        db.session.commit()

        # Notify users (simulated email)
        all_users = User.query.all()
        for user in all_users:
            print(f"[EMAIL SIMULATION] To: {user.email} -- A new movie '{title}' is now available!")

        return "Movie added and users notified."

    return render_template('add_movie.html')

@app.route('/view_users')
def view_users():
    users = User.query.all()
    return render_template('view_users.html', users=users)





@app.route('/view_revenue')
def view_revenue():
    from datetime import datetime
    now = datetime.now()
    month = now.month
    year = now.year

    # Get all payments for the current month
    payments = Payment.query.filter(
        extract('month', Payment.date) == month,
        extract('year', Payment.date) == year
    ).all()

    total_revenue = sum(p.amount for p in payments)
    return render_template('view_revenue.html', payments=payments, total=round(total_revenue, 2), month=month, year=year)
