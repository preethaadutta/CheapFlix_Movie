from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_mail import Mail
# Initialize app, db, and mail
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///cheapflix.db'
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Email configuration (this is just for simulation)
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Use your email provider's SMTP server
app.config['MAIL_PORT'] = 465  # For SSL
app.config['MAIL_USE_SSL'] = True
app.config['MAIL_USERNAME'] = 'your-email@gmail.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = 'your-email-password'  # Replace with your email password
app.config['MAIL_DEFAULT_SENDER'] = 'no-reply@cheapflix.com'  # Default sender

# Initialize db and mail
db = SQLAlchemy(app)
mail = Mail(app)

from app import routes
